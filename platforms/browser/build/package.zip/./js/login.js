var nome = $('#username').val();
var senha = $('#password').val();
if((nome = 'gleidson.fgs@gmail.com') && (senha = 'gleidson99032427')) {
  console.log("Logado!");
}
